create procedure getBooks(IN booksId int)
begin 
  select *from books where Id = booksId;
end;

