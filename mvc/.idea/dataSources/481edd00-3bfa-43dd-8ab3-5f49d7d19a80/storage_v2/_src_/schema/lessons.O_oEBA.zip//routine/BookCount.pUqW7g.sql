create procedure BookCount(OUT cnt int)
BEGIN 
  select count(*) into cnt from books;
END;

